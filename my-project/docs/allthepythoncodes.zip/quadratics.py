try:

    import math
    ask = eval(input("\n\t\t\t>>>Welcome to frank's quadratic room\n\t1. Start\n\n\t2. Quit\n :==> "))

    def solutionofquadractic(a,b,c):
        dicrim = ( (b**2) - (4 * a * c) )
        if dicrim < 0:
            print("\n !! The nature of the root of the quadractic equation is imaginary . Cannot compute...")

        else:
            root1 = ((-1 * b)  +(math.sqrt( (dicrim) )) ) / (2 * a)
            root2 = ((-1 * b)  -(math.sqrt( (dicrim) )) ) / (2 * a)
            print("\n\n Answer:\n\tx = %f\n\n\tx = %f" %(root1, root2))

    def d_property(a,b,c):
        d_Value = ( (b**2) - (4 * a * c))

        if d_Value == 0:
            print("\n\n\t Discriminant D = b^2 - 4ac \n\n\t D = %f^ 2 - (4 x % f x %f )\n\n\t D = 0\n\n\t Since D = 0 , the roots are REAL and EQUAL" %(b, a, c, d_Value))

        elif d_Value > 0:
            print("\n\n\t Discriminant D = b^2 - 4ac \n\n\t D = %f^ 2 - (4 x % f x %f )\n\n\t D = %f\n\n\t Since D > 0, the roots are REAL and UN-EQUAL" %(b, a, c, d_Value))

        else :
            print("\n\n\t Discriminant D = b^2 - 4ac \n\n\t D = %f^ 2 - (4 x % f x %d )\n\n\t D = %f\n\n\t Since D < 0, the roots are IMAGINARY (no real roots)" %(b, a, c, d_Value))


    def quadractics():
        anykey = str(input("\n\t\t Here are the two forms a quadratic equation should be written in. Please Select your format \n\n\t\t1. Standard form: ax^2+ bx + c \n\n\t\t2. Vertex form:  a(x + b)^2+ c \n\n\t\twhere a, b, c, and d are just numbers \n\n Enter any key to continue :==> "))


        coeff_x_squared = eval(input("\nEnter the co-effiecient of x squared (i.e,  a) :==> "))
        coeff_x = eval(input("Enter the co-effiecient of x (i.e,  b):==> "))
        const = eval(input("Enter the constant (i.e,  c):==> "))
        userinput = (input("\n\t\t1. Solve my quadratic equation\n\n\t\t2. View Discriminant property of the quadractic equation\n:==> "))

        if userinput == "1":
            solutionofquadractic(coeff_x_squared , coeff_x, const)

        elif userinput == "2":
            d_property(coeff_x_squared , coeff_x, const)

        else:
            print("Invalid")
            

    while ask != 2:
        quadractics()
        ask = eval(input("\n\n\t1. Continue \n\n\t2. Quit\n :==> "))        

    else:
        print("Thank You for using our services")
        
except:
    ModuleNotFoundError
    print("..........")



