try:
    print("Welcome to Frank's  2 x 2 matrices world\n\n!!! you can only input a maximum of two matices")
    condition = eval(input ("\n\t\t1. * Start\n\t\t2. * Quit\n: ==>"))


        
    def matrixbox():
        m1 = []
        semicolon = ";"
        comma = ","
        rows_n_colums = input("Input row separated by a comma and colums with semi colon\n eg. 2,3;5,7\n : ")

        rows_n_colums = rows_n_colums.split(semicolon)
        firstrow = rows_n_colums[0]
        secondrow = rows_n_colums[1]

        firstrow = firstrow.split(comma)
        firstrow = firstrow[:2]
        secondrow = secondrow.split(comma)
        secondrow = secondrow[:2]
        
        
        for j in firstrow:
            m1.append(int(j))
        for i in secondrow:
            m1.append(int(i))
        return (m1)
        




    def determinant(n):
        majorDiagonal = n[0] * n[3]
        minorDiagonal = n[1] * n[2]
        det = majorDiagonal - minorDiagonal
        return det
        





    while condition == 1:
        finalmatrix = []
        hold1 = eval(input("\n1. Addition of a matrix\n2. Subtraction of a matrix\n3. Multiplication of a matrix\n4. determinant\n: ==>"))
        if hold1 == 1:
            firstmatrix = matrixbox()
            secondmatrix = matrixbox()
            for i in range(4):
                finalmatrix.append(firstmatrix[i] + secondmatrix[i])
            ask = eval(input("\n1. Print out final matrix\n2. Print out the final matrix and its determinant\n: ==>"))
            if ask == 1:
                print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))
            elif ask == 2:
                print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))
                thedeterminant = determinant(finalmatrix)
                print("\nThe determinant is : ==> " + str(thedeterminant))

            
        elif hold1 == 2:
            firstmatrix = matrixbox()
            secondmatrix = matrixbox()
            for i in range(4):
                finalmatrix.append(firstmatrix[i] - secondmatrix[i])
            ask = eval(input("\n1. Print out final matrix\n2. Print out the final matrix and its determinant\n: ==>"))
            if ask == 1:
                print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))
            elif ask == 2:
                print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))
                thedeterminant = determinant(finalmatrix)
                print("\nThe determinant is : ==> " + str(thedeterminant))


        elif hold1 == 3:
            ask = eval(input("\n1. Scalar Multiple\n2. Multiply two matrices\n: ==> "))

            if ask == 1:
                firstmatrix = matrixbox()
                factor = eval(input("Input the scalar\n: ==> "))
                for i in range(4):
                    finalmatrix.append(factor * firstmatrix[i])
                print(" Result\n")
                print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))

            elif ask == 2:
                firstmatrix = matrixbox()
                secondmatrix = matrixbox()
                finalmatrix.append((firstmatrix[0] * secondmatrix[0]) + (firstmatrix[1] * secondmatrix[2]))
                finalmatrix.append((firstmatrix[0] * secondmatrix[1]) + (firstmatrix[1] * secondmatrix[3]))
                finalmatrix.append((firstmatrix[2] * secondmatrix[0]) + (firstmatrix[3] * secondmatrix[2]))
                finalmatrix.append((firstmatrix[2] * secondmatrix[1]) + (firstmatrix[3] * secondmatrix[3]))
                ask1 = eval(input("\n1. Print out final matrix\n2. Print out the final matrix and its determinant\n: ==>"))
                if ask1 == 1:
                    print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))
                elif ask1 == 2:
                    print("\t1st row ==>  %f\t\t%f\n\t2nd row ==>  %f\t\t%f" %(finalmatrix[0],finalmatrix[1],finalmatrix[2],finalmatrix[3]))
                    thedeterminant = determinant(finalmatrix)
                    print("\nThe determinant is : ==> " + str(thedeterminant))

        elif hold1 == 4:
            firstmatrix = matrixbox()
            thedeterminant = determinant(firstmatrix)
            print("\nThe determinant is : ==> " + str(thedeterminant))



        condition = eval(input ("\n\t\t1* Start again \n\t\t2* Quit\n: ==>"))
        
        
    else:
        print("Thank You for using our services")
        



except:
    ModuleNotFoundError
    print("..........")














    
    

