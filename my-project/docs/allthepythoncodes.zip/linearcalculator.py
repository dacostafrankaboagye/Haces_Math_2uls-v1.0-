try:

    import turtle
    
    import tkinter as tk


    ask = eval(input("\n\t\t1. Commence\n\t\t2.Quit\n\t\t==>"))

    while ask == 1:

        def start():  
            t1.color('red')
            t1.up()   
            t1.goto(-200,250)
            t1.down()
            t1.write("Welcome to Frank's linear graphing calculator! " ,False ,'center', font = ('Times new Roman', 20, 'bold'))
            
            
            
            

        def reset():
            t1.reset()
            t2.reset()
            t3.reset()


        def drawaxis():
            t1.up()
            position = t2.position()
            t2.down()
            
            for _ in range(0, 350,50):
                t2.forward(50)
                t2.dot()

            t2.setposition(position)

            for _ in range(0, 350, 50):
                t2.backward(50)
                t2.dot()
            t2.up()
            t2.goto(350,0)
            t2.down()
            t2.write("X-axis" ,False ,'center', font = ('Times new Roman', 15, 'italic'))
            t2.up()
            t2.goto(0,0)
            

            
            t1.reset()
            t1.right(90)
            t1.up()
            t1.goto(0,0)
            t1.down()
            for _ in range(0,350,50):
                t1.forward(50)
                t1.dot()

            t1.goto(0,0)
            t1.left(180)
            
            for _ in range(0,350,50):
                t1.forward(50)
                t1.dot()
                

            t1.up()
            t1.goto(0,350)
            t1.down()
            t1.write("Y-axis" ,False ,'center', font = ('Times new Roman', 15, 'italic'))
            t1.up()
            t1.goto(0,0)
            


        ##__________________________________making the interface to take values_______________________________

        master = tk.Tk()
        tk.Label(master, 
                 text="Coefficient_of_x").grid(row=0)

        tk.Label(master, 
                 text="Intercept").grid(row=1)


        e1 = tk.Entry(master)
        e2 = tk.Entry(master)


        e1.grid(row=0, column=1)
        e2.grid(row=1, column=1)






        def drawingprocess(a,b):
              m = int(a)
              c = int(b)
              t2.up()
              t2.color("red")
              for x in range (-40,40):
                  y = (m * x) + c
                  t2.goto(x, y)
                  t2.down()

        def viewproperties():
            import tkinter as tk
            master = tk.Tk()
            
            a =int(e1.get())
            b = int(e2.get())
            if (a > 0):    

                properties = "Your line is continuously \nINCREASING\n about the x and y axis"

            elif(a<0):
                properties = "Your line is continuously \nDECREASING\n about the x and y axis"

            else:
                properties = "No slope\nHorizontal line"
            msg = tk.Message(master, text = properties)
            msg.config(bg='lightgreen', font=('times', 24, 'italic'))
            msg.pack()
            tk.mainloop()

            
                
                


        def enter_Values():
            a =int(e1.get())
            b = int(e2.get())

            drawingprocess(a,b)





        ##_______________________________using the turtle interface with tkinter________________________
        root = tk.Tk()
        canvas = tk.Canvas(master = root, width = 1000, height = 800)
        canvas.pack()
        t1 = turtle.RawTurtle(canvas)
        t2 = turtle.RawTurtle(canvas)
        t3 = turtle.RawTurtle(canvas)


        ##_________________________________for tkinterinterfaces____________________________________
        tk.Button(master,text='Show', command=enter_Values).grid(row=3,column=0,sticky=tk.W,pady=4)        
        tk.Button(master,text='line_properties', command=viewproperties).grid(row=3,column=1,sticky=tk.W,pady=4)      

        tk.Button(master, text = "start", command = start).grid(row=4,column=0,sticky=tk.W,pady=4)
        tk.Button(master, text = "reset", command = reset).grid(row=4,column=1,sticky=tk.W,pady=4)
        tk.Button(master, text = "drawaxis", command = drawaxis).grid(row=5,column=0,sticky=tk.W,pady=4)


        ##_________________________________ending the root & master tinkter______________________________________
        root.mainloop()
        master.mainloop()
        ask = eval(input("\n\t\t1. Commence again\n\t\t2. Quit\n\t\t ==> "))
    else:
        print("Thank You for using our services")
        


except:
    ModuleNotFoundError
    
    print("..........")



