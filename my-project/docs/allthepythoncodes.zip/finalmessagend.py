print("T H A N K Y O U ")
