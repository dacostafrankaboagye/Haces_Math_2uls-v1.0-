try:
    print("\n\t\t\t\t\t\t\t\t\t\tWelcome to Haces_Maths_2uls!\n Our Tools\t1. Linear Graphing calculator\n\t\t2. Matrices\n\t\t3. Quadratics\n\t\t4.Finish")



    choice = eval (input("Select Any: "))

    while choice!= 4:


        if choice == 1:
            
            from linearcalculator.py import *
            

        elif choice == 2:
    
            from matrices.py import *

        elif choice == 3:
        
            from quadratics.py import *

        choice = eval(input("\n\t\t1. Linear Graphing calculator\n\t\t2. Matrices\n\t\t3. Quadratics\n\t\t4. Sequences\n\t\t5.Finish\n: ==> "))
            
        
    from finalmessageend.py import *

except:
    ModuleNotFoundError
    print("..........")
     
